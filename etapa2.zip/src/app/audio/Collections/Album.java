
package app.audio.Collections;
import app.audio.Files.AudioFile;
import app.audio.Files.Song;

import java.util.List;

public class Album extends AudioCollection {
    private String albumName;
    private int releaseYear;
    private String description;
    private List<Song> songs;
    private String albumOwner;

    public Album(final String albumName, final int releaseYear, final String description,
                 final List<Song> songs, final String albumOwner) {
        super(albumName, albumOwner);
        this.albumName = albumName;
        this.albumOwner = albumOwner;
        this.releaseYear = releaseYear;
        this.songs = songs;
        this.description = description;
    }

    public void setName(final String name) {
        this.albumName = name;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(final int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public List<Song> getSongs() {
        return songs;
    }

    public void setSongs(final List<Song> songs) {
        this.songs = songs;
    }

    public String getAlbumOwner() {
        return albumOwner;
    }

    public void setAlbumOwner(final String albumOwner) {
        this.albumOwner = albumOwner;
    }

    @Override
    public int getNumberOfTracks() {
        return songs.size();
    }

    @Override
    public AudioFile getTrackByIndex(final int index) {
        return songs.get(index);
    }

    @Override
    public boolean matchesDescription(final String description) {
        return this.getDescription().equals(description);
    }

    @Override
    public boolean matchesOwner(final String user) {
        return this.getAlbumOwner().equals(user);
    }

    @Override
    public boolean isAlbum() {
        return true;
    }



}